package com.example.test1;

import android.os.Parcel;
import android.os.Parcelable;

public class FridgeItem implements Parcelable {
    private int imageResId;
    private String name;
    private String storage;  // 보관 방법 (냉장, 냉동, 실외)
    private String quantity; // 수량
    private String expiry;   // 유통기한

    public FridgeItem(int imageResId, String name, String storage, String quantity, String expiry) {
        this.imageResId = imageResId;
        this.name = name;
        this.storage = storage;
        this.quantity = quantity;
        this.expiry = expiry;
    }

    // Parcelable 생성자
    protected FridgeItem(Parcel in) {
        imageResId = in.readInt();
        name = in.readString();
        storage = in.readString();
        quantity = in.readString();
        expiry = in.readString();
    }

    // Getter 메서드들
    public int getImageResId() {
        return imageResId;
    }

    public String getName() {
        return name;
    }

    public String getStorage() {
        return storage;
    }

    public String getQuantity() {
        return quantity;
    }

    public String getExpiry() {
        return expiry;
    }

    // Setter 메서드들
    public void setImageResId(int imageResId) {
        this.imageResId = imageResId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setStorage(String storage) {
        this.storage = storage;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public void setExpiry(String expiry) {
        this.expiry = expiry;
    }

    // Parcelable 구현
    public static final Creator<FridgeItem> CREATOR = new Creator<FridgeItem>() {
        @Override
        public FridgeItem createFromParcel(Parcel in) {
            return new FridgeItem(in);
        }

        @Override
        public FridgeItem[] newArray(int size) {
            return new FridgeItem[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(imageResId);
        dest.writeString(name);
        dest.writeString(storage);
        dest.writeString(quantity);
        dest.writeString(expiry);
    }
}