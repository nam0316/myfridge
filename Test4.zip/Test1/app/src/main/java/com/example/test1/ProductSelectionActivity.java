package com.example.test1;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;

public class ProductSelectionActivity extends AppCompatActivity
        implements ProductSelectionAdapter.OnProductSelectedListener {

    private TabLayout tabCategories;
    private RecyclerView rvProducts;
    private ChipGroup chipGroupStorage;
    private TextInputEditText etQuantity, etExpiry;
    private Button btnAdd, btnCancel, btnDone;
    private MaterialToolbar toolbar;

    private ProductSelectionAdapter productAdapter;
    private ArrayList<ProductItem> allProducts;
    private ArrayList<ProductItem> currentProducts;
    private ArrayList<ProductItem> selectedProducts;

    // 장바구니(임시 저장)
    private ArrayList<FridgeItem> cartItems;

    // 카테고리별 상품 데이터
    private final String[] categories = {"전체", "육류", "야채", "과일", "유제품", "음료", "기타"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_selection);

        initViews();
        setupToolbar();
        setupTabs();
        initSampleData();
        setupRecyclerView();
        setupEventListeners();
    }

    private void initViews() {
        toolbar = findViewById(R.id.toolbar);
        tabCategories = findViewById(R.id.tab_categories);
        rvProducts = findViewById(R.id.rv_products);
        chipGroupStorage = findViewById(R.id.chip_group_storage);
        etQuantity = findViewById(R.id.et_quantity);
        etExpiry = findViewById(R.id.et_expiry);
        btnAdd = findViewById(R.id.btn_add);       // "장바구니에 담기" 역할
        btnCancel = findViewById(R.id.btn_cancel); // 취소
        btnDone = findViewById(R.id.btn_finish);     // "완료" 버튼

        selectedProducts = new ArrayList<>();
        cartItems = new ArrayList<>();
    }

    private void setupToolbar() {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("상품 추가");
        }
    }

    private void setupTabs() {
        for (String category : categories) {
            tabCategories.addTab(tabCategories.newTab().setText(category));
        }

        tabCategories.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                filterProductsByCategory(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });
    }

    private void initSampleData() {
        allProducts = new ArrayList<>();

        // 육류
        allProducts.add(new ProductItem("소고기", R.drawable.ic_launcher_foreground, "육류"));
        allProducts.add(new ProductItem("돼지고기", R.drawable.ic_launcher_foreground, "육류"));
        allProducts.add(new ProductItem("닭고기", R.drawable.ic_launcher_foreground, "육류"));
        allProducts.add(new ProductItem("계란", R.drawable.ic_launcher_foreground, "육류"));

        // 야채
        allProducts.add(new ProductItem("양파", R.drawable.ic_launcher_foreground, "야채"));
        allProducts.add(new ProductItem("당근", R.drawable.ic_launcher_foreground, "야채"));
        allProducts.add(new ProductItem("감자", R.drawable.ic_launcher_foreground, "야채"));
        allProducts.add(new ProductItem("배추", R.drawable.ic_launcher_foreground, "야채"));
        allProducts.add(new ProductItem("상추", R.drawable.ic_launcher_foreground, "야채"));

        // 과일
        allProducts.add(new ProductItem("사과", R.drawable.ic_launcher_foreground, "과일"));
        allProducts.add(new ProductItem("바나나", R.drawable.ic_launcher_foreground, "과일"));
        allProducts.add(new ProductItem("오렌지", R.drawable.ic_launcher_foreground, "과일"));
        allProducts.add(new ProductItem("포도", R.drawable.ic_launcher_foreground, "과일"));

        // 유제품
        allProducts.add(new ProductItem("우유", R.drawable.ic_launcher_foreground, "유제품"));
        allProducts.add(new ProductItem("치즈", R.drawable.ic_launcher_foreground, "유제품"));
        allProducts.add(new ProductItem("요거트", R.drawable.ic_launcher_foreground, "유제품"));
        allProducts.add(new ProductItem("버터", R.drawable.ic_launcher_foreground, "유제품"));

        // 음료
        allProducts.add(new ProductItem("콜라", R.drawable.ic_launcher_foreground, "음료"));
        allProducts.add(new ProductItem("오렌지주스", R.drawable.ic_launcher_foreground, "음료"));
        allProducts.add(new ProductItem("물", R.drawable.ic_launcher_foreground, "음료"));

        // 기타
        allProducts.add(new ProductItem("빵", R.drawable.ic_launcher_foreground, "기타"));
        allProducts.add(new ProductItem("라면", R.drawable.ic_launcher_foreground, "기타"));
        allProducts.add(new ProductItem("아이스크림", R.drawable.ic_launcher_foreground, "기타"));

        currentProducts = new ArrayList<>(allProducts);
    }

    private void setupRecyclerView() {
        rvProducts.setLayoutManager(new GridLayoutManager(this, 4));
        productAdapter = new ProductSelectionAdapter(currentProducts, this);
        rvProducts.setAdapter(productAdapter);
    }

    private void setupEventListeners() {
        // 취소 버튼: 변경하지 않음 (단순 종료, 결과 없음)
        btnCancel.setOnClickListener(v -> finish());

        // 장바구니에 담기 (임시 저장, 전달하지 않음)
        btnAdd.setOnClickListener(v -> addToCart());

        // 완료 버튼: 장바구니 내용을 한꺼번에 전달
        if (btnDone != null) {
            btnDone.setOnClickListener(v -> finishWithCart());
        }

        // 저장소 선택 시, 입력 변화 시 버튼 상태 갱신
        chipGroupStorage.setOnCheckedChangeListener((group, checkedId) -> updateAddButtonState());
        TextWatcherHelper.addTextWatcher(etQuantity, text -> updateAddButtonState());
        TextWatcherHelper.addTextWatcher(etExpiry, text -> updateAddButtonState());
    }

    private void filterProductsByCategory(int categoryIndex) {
        currentProducts.clear();

        if (categoryIndex == 0) { // 전체
            currentProducts.addAll(allProducts);
        } else {
            String selectedCategory = categories[categoryIndex];
            for (ProductItem product : allProducts) {
                if (product.getCategory().equals(selectedCategory)) {
                    currentProducts.add(product);
                }
            }
        }

        productAdapter.updateProducts(currentProducts);
    }

    @Override
    public void onProductSelected(ProductItem product, boolean isSelected) {
        if (isSelected) {
            if (!selectedProducts.contains(product)) selectedProducts.add(product);
        } else {
            selectedProducts.remove(product);
        }
        updateAddButtonState();
    }

    private void updateAddButtonState() {
        boolean hasSelectedProducts = !selectedProducts.isEmpty();
        boolean hasQuantity = !TextUtils.isEmpty(etQuantity.getText());
        boolean hasExpiry = !TextUtils.isEmpty(etExpiry.getText());
        boolean hasStorage = chipGroupStorage.getCheckedChipId() != View.NO_ID;

        btnAdd.setEnabled(hasSelectedProducts && hasQuantity && hasExpiry && hasStorage);
        if (btnDone != null) {
            btnDone.setEnabled(!cartItems.isEmpty()); // 완료는 장바구니가 있을 때만 활성화
        }
    }

    // -------------------
    // 장바구니 관련 메서드
    // -------------------

    // 장바구니에 선택된 상품들을 추가(병합) — "장바구니에 담기" 버튼의 동작
    private void addToCart() {
        if (selectedProducts.isEmpty()) {
            Toast.makeText(this, "상품을 선택해주세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        String quantityStr = etQuantity.getText().toString().trim();
        String expiry = etExpiry.getText().toString().trim();

        if (TextUtils.isEmpty(quantityStr) || TextUtils.isEmpty(expiry)) {
            Toast.makeText(this, "수량과 유통기한을 입력해주세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        // 숫자만 남기기 ("2개" -> "2")
        String digits = quantityStr.replaceAll("[^0-9]", "");
        if (TextUtils.isEmpty(digits)) {
            Toast.makeText(this, "올바른 수량을 입력해주세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantityInt;
        try {
            quantityInt = Integer.parseInt(digits);
            if (quantityInt <= 0) {
                Toast.makeText(this, "수량은 1 이상이어야 합니다.", Toast.LENGTH_SHORT).show();
                return;
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "수량을 숫자로 입력해주세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        String storage = getSelectedStorage();
        if (storage == null) {
            Toast.makeText(this, "보관 방법을 선택해주세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        // 선택된 각 ProductItem -> FridgeItem 생성 및 cart에 병합
        int addedDistinct = 0;
        int addedUnits = 0;
        for (ProductItem product : new ArrayList<>(selectedProducts)) {
            FridgeItem newItem = new FridgeItem(
                    product.getImageResId(),
                    product.getName(),
                    storage,
                    quantityInt,
                    expiry
            );

            boolean merged = mergeIntoCart(newItem);
            if (!merged) {
                cartItems.add(newItem);
                addedDistinct++;
            } else {
                addedDistinct++;
            }
            addedUnits += quantityInt;
        }

        // 선택 해제 및 입력 필드 초기화
        clearSelections();

        Toast.makeText(this, "장바구니에 담겼습니다 (" + addedUnits + "개, 항목 " + cartItems.size() + ")", Toast.LENGTH_SHORT).show();

        // 완료 버튼 활성화 상태 갱신
        updateAddButtonState();
    }

    // 같은 상품(이름, 저장위치, 유통기한)이 장바구니에 있으면 수량 합치기, 있으면 false 반환
    private boolean mergeIntoCart(FridgeItem newItem) {
        for (FridgeItem item : cartItems) {
            if (item.getName().equals(newItem.getName())
                    && item.getStorage().equals(newItem.getStorage())
                    && item.getExpiry().equals(newItem.getExpiry())) {
                item.setQuantity(item.getQuantity() + newItem.getQuantity());
                return true;
            }
        }
        return false;
    }

    // 완료 버튼: cartItems를 한꺼번에 전달해서 종료
    private void finishWithCart() {
        if (cartItems.isEmpty()) {
            Toast.makeText(this, "장바구니에 담긴 상품이 없습니다.", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent resultIntent = new Intent();
        resultIntent.putParcelableArrayListExtra("added_items", cartItems);
        setResult(RESULT_OK, resultIntent);
        int totalDistinct = cartItems.size();
        int totalUnits = 0;
        for (FridgeItem item : cartItems) totalUnits += item.getQuantity();

        // finish 전에 토스트 보여주기 (finish 이후 토스트가 바로 안 보일 수 있음)
        Toast.makeText(this, "완료되었습니다 (" + totalUnits + "개, 항목 " + totalDistinct + ")", Toast.LENGTH_SHORT).show();

        finish();
    }

    private String getSelectedStorage() {
        int checkedId = chipGroupStorage.getCheckedChipId();
        if (checkedId == R.id.chip_storage_fridge) {
            return "냉장";
        } else if (checkedId == R.id.chip_storage_freezer) {
            return "냉동";
        } else if (checkedId == R.id.chip_storage_room) {
            return "실외";
        }
        return null;
    }

    private void clearSelections() {
        // 선택된 상품들의 선택 상태 해제
        for (ProductItem product : selectedProducts) {
            product.setSelected(false);
        }
        selectedProducts.clear();

        // 입력 필드 초기화
        etQuantity.setText("");
        etExpiry.setText("");

        // UI 업데이트
        productAdapter.notifyDataSetChanged();
        updateAddButtonState();
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
