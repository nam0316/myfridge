package com.example.test1;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;

import java.util.ArrayList;

public class ProductSelectionAdapter extends RecyclerView.Adapter<ProductSelectionAdapter.ViewHolder> {

    public interface OnProductSelectedListener {
        void onProductSelected(ProductItem product, boolean isSelected);
    }

    private ArrayList<ProductItem> products;
    private OnProductSelectedListener listener;

    public ProductSelectionAdapter(ArrayList<ProductItem> products, OnProductSelectedListener listener) {
        this.products = products;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_product_selection, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ProductItem product = products.get(position);

        holder.tvProductName.setText(product.getName());
        holder.ivProductImage.setImageResource(product.getImageResId());

        // 선택 상태에 따른 UI 업데이트
        updateSelectionUI(holder, product.isSelected());

        // 클릭 리스너 - 다중 선택 가능
        holder.cardView.setOnClickListener(v -> {
            product.setSelected(!product.isSelected());
            updateSelectionUI(holder, product.isSelected());
            if (listener != null) listener.onProductSelected(product, product.isSelected());
        });

        // 롱클릭으로도 선택 가능
        holder.cardView.setOnLongClickListener(v -> {
            product.setSelected(!product.isSelected());
            updateSelectionUI(holder, product.isSelected());
            if (listener != null) listener.onProductSelected(product, product.isSelected());
            return true;
        });
    }

    private void updateSelectionUI(ViewHolder holder, boolean isSelected) {
        if (isSelected) {
            holder.cardView.setCardElevation(8f);
            holder.cardView.setStrokeWidth(3); // MaterialCardView 전용
            holder.cardView.setStrokeColor(ContextCompat.getColor(
                    holder.itemView.getContext(), R.color.teal_700));
            holder.selectedIndicator.setVisibility(View.VISIBLE);
            holder.selectedIndicator.setBackgroundColor(ContextCompat.getColor(
                    holder.itemView.getContext(), R.color.teal_700));
            holder.tvProductName.setTextColor(ContextCompat.getColor(
                    holder.itemView.getContext(), R.color.teal_700));
        } else {
            holder.cardView.setCardElevation(2f);
            holder.cardView.setStrokeWidth(1);
            holder.cardView.setStrokeColor(ContextCompat.getColor(
                    holder.itemView.getContext(), R.color.light_gray));
            holder.selectedIndicator.setVisibility(View.GONE);
            holder.tvProductName.setTextColor(ContextCompat.getColor(
                    holder.itemView.getContext(), android.R.color.black));
        }
    }

    @Override
    public int getItemCount() {
        return products != null ? products.size() : 0;
    }

    public void updateProducts(ArrayList<ProductItem> newProducts) {
        this.products = newProducts;
        notifyDataSetChanged();
    }

    // 모든 선택 해제
    public void clearAllSelections() {
        for (ProductItem product : products) product.setSelected(false);
        notifyDataSetChanged();
    }

    // 선택된 아이템 개수 반환
    public int getSelectedCount() {
        int count = 0;
        for (ProductItem product : products) if (product.isSelected()) count++;
        return count;
    }

    // 선택된 아이템들 반환
    public ArrayList<ProductItem> getSelectedProducts() {
        ArrayList<ProductItem> selectedProducts = new ArrayList<>();
        for (ProductItem product : products) if (product.isSelected()) selectedProducts.add(product);
        return selectedProducts;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        MaterialCardView cardView; // ★ 타입 변경
        ImageView ivProductImage;
        TextView tvProductName;
        View selectedIndicator;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // ★ 루트 캐스팅 금지, id로 찾기
            cardView = itemView.findViewById(R.id.card_view);
            ivProductImage = itemView.findViewById(R.id.iv_product_image);
            tvProductName = itemView.findViewById(R.id.tv_product_name);
            selectedIndicator = itemView.findViewById(R.id.view_selected_indicator);
        }
    }
}
