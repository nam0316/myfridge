package com.example.test1;

public class Product {
    private int iconResId;
    private String name;
    private String category;
    private String unit;  // ✅ 단위 추가

    public Product(int iconResId, String name, String category, String unit) {
        this.iconResId = iconResId;
        this.name = name;
        this.category = category;
        this.unit = unit;
    }

    public int getIconResId() { return iconResId; }
    public String getName() { return name; }
    public String getCategory() { return category; }
    public String getUnit() { return unit; }   // ✅ 단위 getter 추가

    // 카테고리별 기본 상품 데이터
    public static Product[] getProductsByCategory(String category) {
        switch (category) {
            case "채소":
                return new Product[]{
                        new Product(R.drawable.ic_launcher_foreground, "양파", "채소", "개"),
                        new Product(R.drawable.ic_launcher_foreground, "감자", "채소", "개"),
                        new Product(R.drawable.ic_launcher_foreground, "배추", "채소", "포기"),
                        new Product(R.drawable.ic_launcher_foreground, "오이", "채소", "개"),
                        new Product(R.drawable.ic_launcher_foreground, "토마토", "채소", "개")
                };
            case "과일":
                return new Product[]{
                        new Product(R.drawable.ic_launcher_foreground, "사과", "과일", "개"),
                        new Product(R.drawable.ic_launcher_foreground, "바나나", "과일", "송이"),
                        new Product(R.drawable.ic_launcher_foreground, "딸기", "과일", "팩"),
                        new Product(R.drawable.ic_launcher_foreground, "포도", "과일", "송이"),
                        new Product(R.drawable.ic_launcher_foreground, "수박", "과일", "통")
                };
            case "육류":
                return new Product[]{
                        new Product(R.drawable.ic_launcher_foreground, "소고기", "육류", "g"),
                        new Product(R.drawable.ic_launcher_foreground, "돼지고기", "육류", "g"),
                        new Product(R.drawable.ic_launcher_foreground, "닭고기", "육류", "g"),
                        new Product(R.drawable.ic_launcher_foreground, "계란", "육류", "개"),
                        new Product(R.drawable.ic_launcher_foreground, "베이컨", "육류", "g")
                };
            case "유제품":
                return new Product[]{
                        new Product(R.drawable.ic_launcher_foreground, "우유", "유제품", "ml"),
                        new Product(R.drawable.ic_launcher_foreground, "치즈", "유제품", "g"),
                        new Product(R.drawable.ic_launcher_foreground, "요거트", "유제품", "개"),
                        new Product(R.drawable.ic_launcher_foreground, "버터", "유제품", "g")
                };
            default:
                return new Product[0];
        }
    }

    public static String[] getCategories() {
        return new String[]{"채소", "과일", "육류", "유제품", "냉동식품", "조미료"};
    }
}
