package com.example.test1;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.chip.ChipGroup;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Arrays;
import java.util.List;

public class AddItemDialog extends Dialog {

    public interface OnItemAddListener {
        void onItemAdd(FridgeItem item);
    }

    private OnItemAddListener listener;

    // Views
    private TabLayout tabCategories;
    private RecyclerView rvProducts;
    private LinearLayout layoutSelectedItem;
    private ImageView ivSelectedProduct;
    private TextView tvSelectedProduct;
    private ChipGroup chipGroupStorage;
    private TextInputEditText etQuantity;
    private TextInputEditText etExpiry;
    private Button btnCancel;
    private Button btnAdd;

    // Data
    private ProductAdapter productAdapter;
    private Product selectedProduct;
    private String[] categories;

    public AddItemDialog(@NonNull Context context, OnItemAddListener listener) {
        super(context);
        this.listener = listener;
        this.categories = Product.getCategories();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_add_item);

        initViews();
        setupTabs();
        setupRecyclerView();
        setupListeners();

        // 첫 번째 카테고리 선택
        if (categories.length > 0) {
            loadProducts(categories[0]);
        }
    }

    private void initViews() {
        tabCategories = findViewById(R.id.tab_categories);
        rvProducts = findViewById(R.id.rv_products);
        layoutSelectedItem = findViewById(R.id.layout_selected_item);
        ivSelectedProduct = findViewById(R.id.iv_selected_product);
        tvSelectedProduct = findViewById(R.id.tv_selected_product);
        chipGroupStorage = findViewById(R.id.chip_group_storage);
        etQuantity = findViewById(R.id.et_quantity);
        etExpiry = findViewById(R.id.et_expiry);
        btnCancel = findViewById(R.id.btn_cancel);
        btnAdd = findViewById(R.id.btn_add);
    }

    private void setupTabs() {
        for (String category : categories) {
            tabCategories.addTab(tabCategories.newTab().setText(category));
        }

        tabCategories.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                String category = tab.getText().toString();
                loadProducts(category);
                hideSelectedItem();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });
    }

    private void setupRecyclerView() {
        rvProducts.setLayoutManager(new GridLayoutManager(getContext(), 4));

        productAdapter = new ProductAdapter(Arrays.asList(), product -> {
            selectedProduct = product;
            showSelectedItem(product);
            validateInput();
        });

        rvProducts.setAdapter(productAdapter);
    }

    private void setupListeners() {
        btnCancel.setOnClickListener(v -> dismiss());

        btnAdd.setOnClickListener(v -> {
            if (selectedProduct != null && validateInput()) {
                addItem();
            }
        });

        // 텍스트 변경 리스너
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                validateInput();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        };

        etQuantity.addTextChangedListener(textWatcher);
        etExpiry.addTextChangedListener(textWatcher);
    }

    private void loadProducts(String category) {
        Product[] products = Product.getProductsByCategory(category);
        productAdapter.updateProducts(Arrays.asList(products));
    }

    private void showSelectedItem(Product product) {
        layoutSelectedItem.setVisibility(View.VISIBLE);
        ivSelectedProduct.setImageResource(product.getIconResId());
        tvSelectedProduct.setText(product.getName());

        // 카테고리에 따른 기본 보관방법 설정
        setDefaultStorage(product.getCategory());
    }

    private void hideSelectedItem() {
        layoutSelectedItem.setVisibility(View.GONE);
        selectedProduct = null;
        btnAdd.setEnabled(false);
    }

    private void setDefaultStorage(String category) {
        switch (category) {
            case "냉동식품":
                chipGroupStorage.check(R.id.chip_storage_freezer);
                break;
            case "채소":
            case "과일":
                chipGroupStorage.check(R.id.chip_storage_room);
                break;
            default:
                chipGroupStorage.check(R.id.chip_storage_fridge);
                break;
        }
    }

    private boolean validateInput() {
        String quantity = etQuantity.getText().toString().trim();
        String expiry = etExpiry.getText().toString().trim();

        boolean isValid = selectedProduct != null &&
                !quantity.isEmpty() &&
                !expiry.isEmpty();

        btnAdd.setEnabled(isValid);
        return isValid;
    }

    private void addItem() {
        String quantity = etQuantity.getText().toString().trim();
        String expiry = etExpiry.getText().toString().trim();
        String storage = getSelectedStorage();

        FridgeItem newItem = new FridgeItem(
                selectedProduct.getIconResId(),
                selectedProduct.getName(),
                storage,
                quantity,
                expiry
        );

        if (listener != null) {
            listener.onItemAdd(newItem);
        }

        dismiss();
    }

    private String getSelectedStorage() {
        int checkedId = chipGroupStorage.getCheckedChipId();
        if (checkedId == R.id.chip_storage_freezer) {
            return "냉동";
        } else if (checkedId == R.id.chip_storage_room) {
            return "실외";
        } else {
            return "냉장";
        }
    }
}