package com.example.test1;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.chip.ChipGroup;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;

public class AddItemActivity extends AppCompatActivity {

    // Views
    private ImageView btnBack;
    private TabLayout tabCategories;
    private RecyclerView rvProducts;
    private LinearLayout layoutSelectedItem;
    private ImageView ivSelectedProduct;
    private TextView tvSelectedProduct;
    private ChipGroup chipGroupStorage;
    private TextView tvQuantity;
    private TextView tvExpiryDate;
    private Button btnIncrease;
    private Button btnDecrease;
    private Button btnAdd;
    private Button btnFinish;
    private RecyclerView rvAddedItems;

    // Data
    private ProductAdapter productAdapter;
    private AddedItemsAdapter addedItemsAdapter;
    private Product selectedProduct;
    private String[] categories;
    private ArrayList<FridgeItem> addedItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 타이틀 바 숨기기
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        setContentView(R.layout.activity_add_item);

        categories = Product.getCategories();
        addedItems = new ArrayList<>();

        initViews();
        setupTabs();
        setupProductRecyclerView();
        setupAddedItemsRecyclerView();
        setupListeners();

        // 첫 번째 카테고리 선택
        if (categories.length > 0) {
            loadProducts(categories[0]);
        }
    }

    private void initViews() {
        btnBack = findViewById(R.id.btn_back);
        tabCategories = findViewById(R.id.tab_categories);
        rvProducts = findViewById(R.id.rv_products);
        layoutSelectedItem = findViewById(R.id.layout_selected_item);
        ivSelectedProduct = findViewById(R.id.iv_selected_product);
        tvSelectedProduct = findViewById(R.id.tv_selected_product);
        chipGroupStorage = findViewById(R.id.chip_group_storage);
        tvQuantity = findViewById(R.id.tv_quantity);
        tvExpiryDate = findViewById(R.id.tv_expiry_date);
        btnIncrease = findViewById(R.id.btn_increase);
        btnDecrease = findViewById(R.id.btn_decrease);
        btnAdd = findViewById(R.id.btn_add);
        btnFinish = findViewById(R.id.btn_finish);
        rvAddedItems = findViewById(R.id.rv_added_items);
    }

    private void setupTabs() {
        for (String category : categories) {
            tabCategories.addTab(tabCategories.newTab().setText(category));
        }

        tabCategories.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                String category = tab.getText().toString();
                loadProducts(category);
                hideSelectedItem();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });
    }

    private void setupProductRecyclerView() {
        rvProducts.setLayoutManager(new GridLayoutManager(this, 4));

        productAdapter = new ProductAdapter(Arrays.asList(), product -> {
            selectedProduct = product;
            showSelectedItem(product);
            validateInput();
        });

        rvProducts.setAdapter(productAdapter);
    }

    private void setupAddedItemsRecyclerView() {
        rvAddedItems.setLayoutManager(new LinearLayoutManager(this));
        addedItemsAdapter = new AddedItemsAdapter(addedItems, position -> {
            addedItems.remove(position);
            addedItemsAdapter.notifyItemRemoved(position);
            updateAddedItemsVisibility();
            Toast.makeText(this, "아이템이 삭제되었습니다", Toast.LENGTH_SHORT).show();
        });
        rvAddedItems.setAdapter(addedItemsAdapter);
    }

    private void setupListeners() {
        btnBack.setOnClickListener(v -> {
            if (!addedItems.isEmpty()) {
                Intent resultIntent = new Intent();
                resultIntent.putParcelableArrayListExtra("added_items", addedItems);
                setResult(RESULT_OK, resultIntent);
            }
            finish();
        });

        btnAdd.setOnClickListener(v -> {
            if (selectedProduct != null && validateInput()) {
                addItemToList();
            }
        });

        btnFinish.setOnClickListener(v -> {
            if (!addedItems.isEmpty()) {
                Intent resultIntent = new Intent();
                resultIntent.putParcelableArrayListExtra("added_items", addedItems);
                setResult(RESULT_OK, resultIntent);
            }
            finish();
        });

        btnIncrease.setOnClickListener(v -> {
            int quantity = Integer.parseInt(tvQuantity.getText().toString());
            tvQuantity.setText(String.valueOf(quantity + 1));
            validateInput();
        });

        btnDecrease.setOnClickListener(v -> {
            int quantity = Integer.parseInt(tvQuantity.getText().toString());
            if (quantity > 1) {
                tvQuantity.setText(String.valueOf(quantity - 1));
                validateInput();
            }
        });

        tvExpiryDate.setOnClickListener(v -> showDatePicker());
    }

    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog datePicker = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    tvExpiryDate.setText(String.format("%04d-%02d-%02d", year, month + 1, dayOfMonth));
                    validateInput();
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );
        datePicker.show();
    }

    private void loadProducts(String category) {
        Product[] products = Product.getProductsByCategory(category);
        productAdapter.updateProducts(Arrays.asList(products));
    }

    private void showSelectedItem(Product product) {
        layoutSelectedItem.setVisibility(View.VISIBLE);
        ivSelectedProduct.setImageResource(product.getIconResId());
        tvSelectedProduct.setText(product.getName());

        tvQuantity.setText("1");
        tvExpiryDate.setText("날짜 선택");

        setDefaultStorage(product.getCategory());
        validateInput();
    }

    private void hideSelectedItem() {
        layoutSelectedItem.setVisibility(View.GONE);
        selectedProduct = null;
        btnAdd.setEnabled(false);
    }

    private void setDefaultStorage(String category) {
        switch (category) {
            case "냉동식품":
                chipGroupStorage.check(R.id.chip_storage_freezer);
                break;
            case "채소":
            case "과일":
                chipGroupStorage.check(R.id.chip_storage_room);
                break;
            default:
                chipGroupStorage.check(R.id.chip_storage_fridge);
                break;
        }
    }

    private boolean validateInput() {
        String quantityStr = tvQuantity.getText().toString().trim();
        String expiryStr = tvExpiryDate.getText().toString().trim();

        boolean isValid = selectedProduct != null &&
                !quantityStr.isEmpty() &&
                !expiryStr.isEmpty() &&
                !expiryStr.equals("날짜 선택");

        btnAdd.setEnabled(isValid);
        return isValid;
    }

    private void addItemToList() {
        String quantity = tvQuantity.getText().toString().trim();
        String expiry = tvExpiryDate.getText().toString().trim();
        String storage = getSelectedStorage();

        FridgeItem newItem = new FridgeItem(
                selectedProduct.getIconResId(),
                selectedProduct.getName(),
                storage,
                quantity,
                expiry
        );

        addedItems.add(newItem);
        addedItemsAdapter.notifyItemInserted(addedItems.size() - 1);

        updateAddedItemsVisibility();

        Toast.makeText(this, selectedProduct.getName() + "이(가) 추가되었습니다!", Toast.LENGTH_SHORT).show();

        tvQuantity.setText("1");
        tvExpiryDate.setText("날짜 선택");
        btnAdd.setEnabled(false);

        rvAddedItems.smoothScrollToPosition(addedItems.size() - 1);
    }

    private void updateAddedItemsVisibility() {
        findViewById(R.id.layout_added_items).setVisibility(
                addedItems.isEmpty() ? LinearLayout.GONE : LinearLayout.VISIBLE
        );

        TextView tvAddedCount = findViewById(R.id.tv_added_count);
        if (tvAddedCount != null) {
            tvAddedCount.setText("추가된 상품 (" + addedItems.size() + "개)");
        }
    }

    private String getSelectedStorage() {
        int checkedId = chipGroupStorage.getCheckedChipId();
        if (checkedId == R.id.chip_storage_freezer) {
            return "냉동";
        } else if (checkedId == R.id.chip_storage_room) {
            return "실외";
        } else {
            return "냉장";
        }
    }

    @Override
    public void onBackPressed() {
        btnBack.performClick();
    }
}
