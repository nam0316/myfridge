package com.example.test1;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class FridgeAdapter extends RecyclerView.Adapter<FridgeAdapter.FridgeViewHolder> {

    private ArrayList<FridgeItem> items;

    public FridgeAdapter(ArrayList<FridgeItem> items) {
        this.items = items != null ? items : new ArrayList<>();
    }

    @NonNull
    @Override
    public FridgeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_fridge, parent, false);
        return new FridgeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FridgeViewHolder holder, int position) {
        FridgeItem item = items.get(position);
        holder.bind(item);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public static class FridgeViewHolder extends RecyclerView.ViewHolder {
        private ImageView ivItemImage;
        private TextView tvItemName;
        private TextView tvStorage;
        private TextView tvQuantity;
        private TextView tvExpiry;

        public FridgeViewHolder(@NonNull View itemView) {
            super(itemView);
            initViews(itemView);
        }

        private void initViews(View itemView) {
            ivItemImage = itemView.findViewById(R.id.iv_item_image);
            tvItemName = itemView.findViewById(R.id.tv_item_name);
            tvStorage = itemView.findViewById(R.id.tv_storage);
            tvQuantity = itemView.findViewById(R.id.tv_quantity);
            tvExpiry = itemView.findViewById(R.id.tv_expiry);
        }

        public void bind(FridgeItem item) {
            if (item != null) {
                // 이미지 설정
                if (ivItemImage != null) {
                    ivItemImage.setImageResource(item.getImageResId());
                }

                // 아이템 이름 설정
                if (tvItemName != null) {
                    tvItemName.setText(item.getName());
                }

                // 보관 방법 설정
                if (tvStorage != null) {
                    tvStorage.setText(item.getStorage());
                }

                // 수량 설정 (여기 수정: "개" 붙임)
                if (tvQuantity != null) {
                    tvQuantity.setText(item.getQuantity() + "개");
                }

                // 유통기한 설정
                if (tvExpiry != null) {
                    tvExpiry.setText(item.getExpiry());

                    // 유통기한에 따른 색상 변경
                    setExpiryColor(item.getExpiry());
                }
            }
        }

        private void setExpiryColor(String expiry) {
            if (tvExpiry == null || expiry == null) {
                return;
            }

            // D-3 이하는 빨간색, D-7 이하는 주황색, 나머지는 기본색
            if (expiry.startsWith("D-")) {
                try {
                    int days = Integer.parseInt(expiry.substring(2));
                    if (days <= 3) {
                        tvExpiry.setTextColor(ContextCompat.getColor(itemView.getContext(), android.R.color.holo_red_dark));
                    } else if (days <= 7) {
                        tvExpiry.setTextColor(ContextCompat.getColor(itemView.getContext(), android.R.color.holo_orange_dark));
                    } else {
                        tvExpiry.setTextColor(ContextCompat.getColor(itemView.getContext(), android.R.color.darker_gray));
                    }
                } catch (NumberFormatException e) {
                    tvExpiry.setTextColor(ContextCompat.getColor(itemView.getContext(), android.R.color.darker_gray));
                }
            } else {
                // "신선함" 같은 경우
                tvExpiry.setTextColor(ContextCompat.getColor(itemView.getContext(), android.R.color.holo_green_dark));
            }
        }
    }
}
