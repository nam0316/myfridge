package com.example.test1;

public class Product {
    private int iconResId;
    private String name;
    private String category;

    public Product(int iconResId, String name, String category) {
        this.iconResId = iconResId;
        this.name = name;
        this.category = category;
    }

    public int getIconResId() {
        return iconResId;
    }

    public String getName() {
        return name;
    }

    public String getCategory() {
        return category;
    }

    // 카테고리별 기본 상품 데이터
    public static Product[] getProductsByCategory(String category) {
        switch (category) {
            case "채소":
                return new Product[]{
                        new Product(R.drawable.ic_launcher_foreground, "양파", "채소"),
                        new Product(R.drawable.ic_launcher_foreground, "감자", "채소"),
                        new Product(R.drawable.ic_launcher_foreground, "당근", "채소"),
                        new Product(R.drawable.ic_launcher_foreground, "배추", "채소"),
                        new Product(R.drawable.ic_launcher_foreground, "무", "채소"),
                        new Product(R.drawable.ic_launcher_foreground, "파", "채소"),
                        new Product(R.drawable.ic_launcher_foreground, "마늘", "채소"),
                        new Product(R.drawable.ic_launcher_foreground, "생강", "채소"),
                        new Product(R.drawable.ic_launcher_foreground, "오이", "채소"),
                        new Product(R.drawable.ic_launcher_foreground, "토마토", "채소")
                };
            case "과일":
                return new Product[]{
                        new Product(R.drawable.ic_launcher_foreground, "사과", "과일"),
                        new Product(R.drawable.ic_launcher_foreground, "바나나", "과일"),
                        new Product(R.drawable.ic_launcher_foreground, "오렌지", "과일"),
                        new Product(R.drawable.ic_launcher_foreground, "딸기", "과일"),
                        new Product(R.drawable.ic_launcher_foreground, "포도", "과일"),
                        new Product(R.drawable.ic_launcher_foreground, "배", "과일"),
                        new Product(R.drawable.ic_launcher_foreground, "복숭아", "과일"),
                        new Product(R.drawable.ic_launcher_foreground, "키위", "과일"),
                        new Product(R.drawable.ic_launcher_foreground, "망고", "과일"),
                        new Product(R.drawable.ic_launcher_foreground, "파인애플", "과일")
                };
            case "육류":
                return new Product[]{
                        new Product(R.drawable.ic_launcher_foreground, "소고기", "육류"),
                        new Product(R.drawable.ic_launcher_foreground, "돼지고기", "육류"),
                        new Product(R.drawable.ic_launcher_foreground, "닭고기", "육류"),
                        new Product(R.drawable.ic_launcher_foreground, "계란", "육류"),
                        new Product(R.drawable.ic_launcher_foreground, "베이컨", "육류"),
                        new Product(R.drawable.ic_launcher_foreground, "소시지", "육류"),
                        new Product(R.drawable.ic_launcher_foreground, "햄", "육류"),
                        new Product(R.drawable.ic_launcher_foreground, "닭가슴살", "육류")
                };
            case "유제품":
                return new Product[]{
                        new Product(R.drawable.ic_launcher_foreground, "우유", "유제품"),
                        new Product(R.drawable.ic_launcher_foreground, "치즈", "유제품"),
                        new Product(R.drawable.ic_launcher_foreground, "요거트", "유제품"),
                        new Product(R.drawable.ic_launcher_foreground, "버터", "유제품"),
                        new Product(R.drawable.ic_launcher_foreground, "생크림", "유제품"),
                        new Product(R.drawable.ic_launcher_foreground, "크림치즈", "유제품")
                };
            case "냉동식품":
                return new Product[]{
                        new Product(R.drawable.ic_launcher_foreground, "아이스크림", "냉동식품"),
                        new Product(R.drawable.ic_launcher_foreground, "만두", "냉동식품"),
                        new Product(R.drawable.ic_launcher_foreground, "냉동피자", "냉동식품"),
                        new Product(R.drawable.ic_launcher_foreground, "냉동치킨", "냉동식품"),
                        new Product(R.drawable.ic_launcher_foreground, "냉동새우", "냉동식품"),
                        new Product(R.drawable.ic_launcher_foreground, "냉동야채", "냉동식품")
                };
            case "조미료":
                return new Product[]{
                        new Product(R.drawable.ic_launcher_foreground, "소금", "조미료"),
                        new Product(R.drawable.ic_launcher_foreground, "설탕", "조미료"),
                        new Product(R.drawable.ic_launcher_foreground, "간장", "조미료"),
                        new Product(R.drawable.ic_launcher_foreground, "고추장", "조미료"),
                        new Product(R.drawable.ic_launcher_foreground, "된장", "조미료"),
                        new Product(R.drawable.ic_launcher_foreground, "식용유", "조미료"),
                        new Product(R.drawable.ic_launcher_foreground, "참기름", "조미료"),
                        new Product(R.drawable.ic_launcher_foreground, "식초", "조미료")
                };
            default:
                return new Product[0];
        }
    }

    public static String[] getCategories() {
        return new String[]{"채소", "과일", "육류", "유제품", "냉동식품", "조미료"};
    }
}