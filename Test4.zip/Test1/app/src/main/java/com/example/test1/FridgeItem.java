package com.example.test1;

import android.os.Parcel;
import android.os.Parcelable;

public class FridgeItem implements Parcelable {
    private int imageResId;
    private String name;
    private String storage;
    private int quantity;
    private String unit;
    private String expiry;

    // 생성자 1: 모든 필드를 받는 생성자
    public FridgeItem(int imageResId, String name, String storage, int quantity, String unit, String expiry) {
        this.imageResId = imageResId;
        this.name = name;
        this.storage = storage;
        this.quantity = quantity;
        this.unit = unit;
        this.expiry = expiry;
    }

    // 생성자 2: unit 없는 생성자 (단위 기본값 "개")
    public FridgeItem(int imageResId, String name, String storage, int quantity, String expiry) {
        this(imageResId, name, storage, quantity, "개", expiry);
    }

    // Parcelable 생성자
    protected FridgeItem(Parcel in) {
        imageResId = in.readInt();
        name = in.readString();
        storage = in.readString();
        quantity = in.readInt();
        unit = in.readString();
        expiry = in.readString();
    }

    public static final Creator<FridgeItem> CREATOR = new Creator<FridgeItem>() {
        @Override
        public FridgeItem createFromParcel(Parcel in) {
            return new FridgeItem(in);
        }

        @Override
        public FridgeItem[] newArray(int size) {
            return new FridgeItem[size];
        }
    };

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(imageResId);
        dest.writeString(name);
        dest.writeString(storage);
        dest.writeInt(quantity);
        dest.writeString(unit);
        dest.writeString(expiry);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    // Getter
    public int getImageResId() { return imageResId; }
    public String getName() { return name; }
    public String getStorage() { return storage; }
    public int getQuantity() { return quantity; }
    public String getUnit() { return unit; }
    public String getExpiry() { return expiry; }

    // Setter
    public void setImageResId(int imageResId) { this.imageResId = imageResId; }
    public void setName(String name) { this.name = name; }
    public void setStorage(String storage) { this.storage = storage; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public void setUnit(String unit) { this.unit = unit; }
    public void setExpiry(String expiry) { this.expiry = expiry; }

    // 화면 표시용
    public String getQuantityText() {
        return quantity + unit;  // 예: "3개", "500g"
    }

    @Override
    public String toString() {
        return "FridgeItem{" +
                "name='" + name + '\'' +
                ", storage='" + storage + '\'' +
                ", quantity=" + quantity +
                ", unit='" + unit + '\'' +
                ", expiry='" + expiry + '\'' +
                '}';
    }
}
